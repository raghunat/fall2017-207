<!DOCTYPE html>
<html>
  <head>
    <title>Basic Template For PHP Class</title>
  </head>
  <body>
      <?php echo 10 ?>
  </body>
</html>
