<!DOCTYPE html>
<html>
  <head>
    <title>Create Form</title>
  </head>
  <body>
    <form action="insert.php" method="POST">
      <label for="name">Name:</label>
      <input id="name" type="text" name="name">
      <br>
      <label for="email">Email:</label>
      <input id="email" type="text" name="email">
      <br>
      <input type="submit" value="Add My Record">
    </form>
  </body>
</html>