<html>
  <head>
    <title>Get Form</title>
  </head>
  <body>
    <form  action="writeToFile.php" method="POST">
      <label for="firstName">First Name:</label>
      <input type="text" name="firstName"/>
      <br>
      <label for="lastName">Last Name:</label>
      <input type="text" name="lastName"/>
      <br>
      <label for="email">Email:</label>
      <input type="text" name="email">
      <input type="submit" name="submit" value="Submit">
    </form>
  </body>
</html>
