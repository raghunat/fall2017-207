<html>
<head>
	<title>PHP String Functions Assignment</title>
</head>
<body>
	<pre>
	<?php echo strtoupper("two"); ?> roads diverged in a yellow wood,
	And sorry I could not travel both
	And be one <?php echo substr("ttraveler", 1); ?>, long I stood
	And looked down one as far as I could
	To where it bent in the undergrowth;

	Then took the other, as just as fair,
	And having perhaps the betterr claim,
	Because it was grassy and wanted wear;
	Though as for that the passing there
	Had worn tthem really about the same,

	And both that morning equally layy
	In leaves no foot had trodden black.
	Oh, I keptt the first for another day!
	Yet knowing how way leads on to way,
	I doubted if I should ever come back.

	I shall be telling this with a sigh
	Somewire ages and ages hence:
	Two roads diverged in a wood, and i-
	I took the one less TRAVELED by,
	And that has made all the difference.

	</pre>
</body>
</html>
