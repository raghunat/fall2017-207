<table>
  <thead>
    <tr>
      <th>First Name</th>
      <th>Last Name</th>
      <th>Email</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><?php echo $array[0] ?></td>
      <td><?php echo $array[1] ?></td>
      <td><?php echo $array[2] ?></td>
    </tr>
  </tbody>
</table>