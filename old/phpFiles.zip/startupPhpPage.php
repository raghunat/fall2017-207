<!DOCTYPE html>
<html>
  <head>
    <title>Basic Template For PHP Class</title>
  </head>
  <body>
    <?php
      echo "Hello There";
      echo "<br>";
      echo 10;
      echo "<br>";

      // Concatenation
      // Results in  "Hello There"
      echo "Hello " . "There";
      echo "<br>";

      //Results in "Hello my 24 students"
      echo "Hello my " . 24 . " students";
      echo "<br>";

      //Results in 22
      echo "2" . 2;
      echo "<br>";

      //Results in 8
      echo 2 + 4 + 2;
      echo "<br>";

      //Results in 36
      echo "2" + "2" + 32;
      echo "<br>";
     ?>
  </body>
</html>
